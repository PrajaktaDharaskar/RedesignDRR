// Function to update the 'Month' and 'Year' based on selected dates
function updateMonthYear() {
    const startDate = new Date(document.getElementById("start-date").value);
    const endDate = new Date(document.getElementById("end-date").value);
  
    const startMonth = startDate.toLocaleString('default', { month: 'long' });
    const startYear = startDate.getFullYear();
    document.getElementById("month").textContent = startMonth;
    document.getElementById("year").textContent = startYear;
  }
  
  // Function to add excluded dates to the date picker
  function addExcludedDate(date) {
    const excludedDates = document.getElementById("excluded-dates");
    const excludedDateElement = document.createElement("span");
    excludedDateElement.textContent = date + " ";
    excludedDates.appendChild(excludedDateElement);
  }
  
  // Function to calculate 'Expected Lead Count' based on 'Number of Leads'
  function calculateExpectedLeadCount() {
    const numberOfLeads = parseInt(document.getElementById("number-of-leads").value);
    const startDate = new Date(document.getElementById("start-date").value);
    const endDate = new Date(document.getElementById("end-date").value);
  
    const days = (endDate - startDate) / (1000 * 60 * 60 * 24);
    const expectedLeadCount = numberOfLeads / (days + 1);
  
    document.getElementById("expected-lead-count").textContent = expectedLeadCount.toFixed(2);
  }
  
  // Event listeners
  document.getElementById("start-date").addEventListener("input", updateMonthYear);
  document.getElementById("end-date").addEventListener("input", updateMonthYear);
  document.getElementById("number-of-leads").addEventListener("input", calculateExpectedLeadCount);
  
  document.getElementById("save-button").addEventListener("click", function () {
    // Use AJAX for data submission
    // You can implement your AJAX request here
  });
  